import{j as o}from"./index.d539a79b.js";const s=()=>o("div",{children:"work flow  logs"});export{s as default};
