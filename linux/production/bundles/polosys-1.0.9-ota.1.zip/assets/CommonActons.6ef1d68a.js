import{A as t}from"./index.d539a79b.js";function n(o){return{type:t.SET_TOKEN,payload:o}}export{n as s};
