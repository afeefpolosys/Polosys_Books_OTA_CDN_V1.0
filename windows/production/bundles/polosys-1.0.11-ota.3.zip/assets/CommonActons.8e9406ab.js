import{av as t}from"./index.a8427b6b.js";function e(o){return{type:t.SET_TOKEN,payload:o}}export{e as s};
