import{c9 as s,j as t,L as n}from"./index.a8427b6b.js";const p=({flag:e,children:a})=>s(e)?t(n,{children:a}):null;export{p as I};
