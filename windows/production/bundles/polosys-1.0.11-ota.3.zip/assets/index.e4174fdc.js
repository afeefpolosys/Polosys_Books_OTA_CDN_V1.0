import{j as o}from"./index.a8427b6b.js";const s=()=>o("div",{children:"work flow  logs"});export{s as default};
