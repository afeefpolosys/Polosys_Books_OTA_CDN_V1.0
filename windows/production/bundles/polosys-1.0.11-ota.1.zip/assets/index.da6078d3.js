import{j as o}from"./index.ecf98412.js";const s=()=>o("div",{children:"work flow  logs"});export{s as default};
