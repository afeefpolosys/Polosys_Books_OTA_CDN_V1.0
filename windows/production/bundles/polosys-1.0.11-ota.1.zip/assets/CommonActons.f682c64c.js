import{A as t}from"./index.ecf98412.js";function n(o){return{type:t.SET_TOKEN,payload:o}}export{n as s};
