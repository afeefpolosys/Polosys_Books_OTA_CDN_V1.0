import{A as t}from"./index.f3aa089f.js";function n(o){return{type:t.SET_TOKEN,payload:o}}export{n as s};
