import{j as o}from"./index.f3aa089f.js";const s=()=>o("div",{children:"work flow  logs"});export{s as default};
