import{j as o}from"./index.2e1870d8.js";const s=()=>o("div",{children:"work flow  logs"});export{s as default};
