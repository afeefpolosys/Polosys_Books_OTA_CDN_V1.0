import{A as t}from"./index.2e1870d8.js";function n(o){return{type:t.SET_TOKEN,payload:o}}export{n as s};
