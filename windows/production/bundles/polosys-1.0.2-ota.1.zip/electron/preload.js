const { contextBridge, ipcRenderer } = require('electron');

const electronApi = {
  platform: process.platform,
  isElectron: true,
  // OTA APIs
  otaDownloadAndExtract: (bundleUrl, bundleId) =>
    ipcRenderer.invoke('ota-download-and-extract', { bundleUrl, bundleId }),
  otaGetCurrentState: () =>
    ipcRenderer.invoke('ota-get-current-state'),
  otaResetToBuiltin: () =>
    ipcRenderer.invoke('ota-reset-to-builtin'),
  reloadApp: () =>
    ipcRenderer.invoke('reload-app'),
};

contextBridge.exposeInMainWorld('electron', electronApi);
contextBridge.exposeInMainWorld('electronAPI', electronApi);
