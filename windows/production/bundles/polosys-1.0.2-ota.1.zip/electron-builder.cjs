module.exports = {
  appId: "com.polosys.books",
  productName: "Polosys Books",
  electronVersion: "44.5.1",
  directories: {
    output: "../release",
  },
  files: [
    "**/*",
  ],
  win: {
    target: [
      {
        target: "nsis",
        arch: ["x64"]
      }
    ],
    icon: "icon.png",
    artifactName: "${productName}-Setup-${version}.${ext}"
  },
  mac: {
    target: [
      {
        target: "dmg",
        arch: ["x64", "arm64"]
      }
    ],
    icon: "icon.png",
    artifactName: "${productName}-${version}-${arch}.${ext}"
  },
  linux: {
    target: [
      {
        target: "AppImage",
        arch: ["x64"]
      },
      {
        target: "deb",
        arch: ["x64"]
      }
    ],
    icon: "icon.png",
    artifactName: "${productName}-${version}-${arch}.${ext}"
  },
  nsis: {
    oneClick: false,
    allowToChangeInstallationDirectory: true,
  },
  npmRebuild: false,
};
