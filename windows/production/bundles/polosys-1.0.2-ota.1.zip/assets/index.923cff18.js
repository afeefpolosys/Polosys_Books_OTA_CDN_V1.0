import{j as o}from"./index.667bc0bc.js";const s=()=>o("div",{children:"work flow  logs"});export{s as default};
