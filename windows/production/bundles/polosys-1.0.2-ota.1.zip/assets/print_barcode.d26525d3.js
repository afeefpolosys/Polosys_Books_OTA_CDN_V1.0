import{r as c,a as Xa,aC as Wa,G as Ga,U as Ye,t as Ka,h as qa,gj as Va,b as l,j as a,a6 as s,F as Je,e5 as Qa,S as y,H as oa,f as ya,aJ as Za}from"./index.667bc0bc.js";const et={A4:{pageSize:"A4",columns:"auto",isThermal:!1},THERMAL_50_30:{pageSize:"50mm 30mm",columns:"1fr",isThermal:!0},THERMAL_40_25:{pageSize:"40mm 25mm",columns:"1fr",isThermal:!0}},at=[{name:"classic / balanced",style:"classic",width:30,height:20,margins:{top:4,bottom:4,left:4,right:4},fontSize:7,description:"traditional layout with item name, price, and barcode. Best for small items."},{name:"compliance Label (Price Focus)",style:"price-focus",width:38,height:25,margins:{top:4,bottom:4,left:4,right:4},fontSize:6,description:"features a large prominent price. Ideal for promotional or retail setups."},{name:"classic + best before (Compact)",style:"compact",width:38,height:25,margins:{top:4,bottom:4,left:4,right:4},fontSize:7,description:"dense layout emphasizing expiry date, batch, and best before details."},{name:"detailed label (Elegant)",style:"elegant",width:60,height:40,margins:{top:4,bottom:4,left:4,right:4},fontSize:9,description:"premium look with secondary language name support, generous spacing, and tax info."}];function st(){var fa,xa;const[Xe,Na]=c.exports.useState("items"),Z=Xa(),[Me,Pe]=c.exports.useState([]),[$e,ne]=c.exports.useState("A4"),Be=et[$e],ee=Be==null?void 0:Be.isThermal,[N,S]=c.exports.useState({width:30,height:20}),[w,B]=c.exports.useState({top:6,bottom:6,left:6,right:6}),[oe,ce]=c.exports.useState(3),[de,ie]=c.exports.useState(4),[Ce,ca]=c.exports.useState({row:1,column:1}),[p,da]=c.exports.useState("classic"),[_a,ze]=c.exports.useState(!1),[u,he]=c.exports.useState(7),[pe,ue]=c.exports.useState(!0),[F,U]=c.exports.useState(!1),[ge,me]=c.exports.useState(!0),[wa,ke]=c.exports.useState(!1),[E,J]=c.exports.useState(!1),[Ae,be]=c.exports.useState(!0),[D,X]=c.exports.useState(!1),[Ee,fe]=c.exports.useState(!1),[Y,$]=c.exports.useState(!1),[z,W]=c.exports.useState(!1),[A,G]=c.exports.useState(!1),[T,K]=c.exports.useState(!1),[q,xe]=c.exports.useState(!1),[j,We]=c.exports.useState(""),[R,Ge]=c.exports.useState(""),[H,Ke]=c.exports.useState(""),[C,qe]=c.exports.useState(""),[I,ia]=c.exports.useState(""),[je,ve]=c.exports.useState(!1),[Re,Ve]=c.exports.useState(!1),[V,Qe]=c.exports.useState("DD-MM-YYYY"),[Q,Ze]=c.exports.useState(!1),Ya=(e={})=>{var r,n,o,d,i,t,x,b,m,L,P,f,M,v,O,ae,te,le,se,re;ue((r=e.item_name)!=null?r:!0),U((n=e.arabic_name)!=null?n:!1),me((o=e.selling_price)!=null?o:!0),ke((d=e.cost_price)!=null?d:!1),J((i=e.unit)!=null?i:!1),be((t=e.barcode_text)!=null?t:!0),X((x=e.cost_code)!=null?x:!1),fe((b=e.show_border)!=null?b:!1),$((m=e.note1)!=null?m:!1),W((L=e.note2)!=null?L:!1),G((P=e.package_date)!=null?P:!1),K((f=e.expiry_date)!=null?f:!1),xe((M=e.title_header)!=null?M:!1),We(e.title_text||""),Ge(e.note1_text||""),Ke(e.note2_text||""),qe(e.package_date_value||""),Ze(e.use_manual_barcode||!1),Ve(e.change_date_format||!1),ve(e.inclusive||!1),e.page&&(ne((v=e.page.page_type)!=null?v:"A4"),S({width:Number(e.page.label_width)||50,height:Number(e.page.label_height)||30}),ie((O=e.page.columns)!=null?O:""),ce((ae=e.page.rows)!=null?ae:"")),e.margin&&(B({top:(te=e.margin.top)!=null?te:6,right:(le=e.margin.right)!=null?le:6,bottom:(se=e.margin.bottom)!=null?se:6,left:(re=e.margin.left)!=null?re:6}),he(Number(e.margin.font_size)||7)),Qe(e.date_format_value||"DD-MM-YYYY"),e.cost_code_mapping&&typeof e.cost_code_mapping=="object"&&ye(Object.entries(e.cost_code_mapping).map(([we,Ue])=>({number:Number(we),value:String(Ue||"?").slice(0,1).toUpperCase()})))},[_,ye]=c.exports.useState(Array.from({length:10},(e,r)=>({number:r,value:String.fromCharCode(65+r)}))),He=c.exports.useMemo(()=>{const e={};return _.forEach(r=>e[r.number]=r.value),e},[_]);function Ie(e,r){if(e===0)return r[0];let n="";const o=Object.keys(r).length;for(;e>0;){const d=e%o;n=r[d]+n,e=Math.floor(e/o)}return n}const ha=(e,r)=>{const n=[..._];n[e].value=r.slice(0,1).toUpperCase(),ye(n)},[g,pa]=c.exports.useState({from:0,to:0}),[ea,Ma]=c.exports.useState(""),[k,aa]=c.exports.useState({vprefix:"",form_type:"sales_est",bill_no:""}),[ta,ua]=c.exports.useState(null),[Ne,Ca]=c.exports.useState(null),Te=c.exports.useRef(null),[Se,ka]=c.exports.useState(Wa()),Sa=Ga(Ye.user_companies,"GET"),Da=(xa=(fa=Ka(e=>e==null?void 0:e[Sa]))==null?void 0:fa.data)==null?void 0:xa.find(e=>(e==null?void 0:e.is_active)==!0);c.exports.useEffect(()=>{Se||Z(qa()).then(e=>{var r,n,o,d;ka((d=(o=(n=(r=e==null?void 0:e.payload)==null?void 0:r.data)==null?void 0:n.find(i=>i==null?void 0:i.is_active))==null?void 0:o.currency)==null?void 0:d.symbol)})},[Da]);const ga=N.width,la=c.exports.useMemo(()=>de&&de>0?de:Math.floor(210/ga),[de,ga]),$a=c.exports.useMemo(()=>oe&&oe>0?oe:Math.floor(297/N.height),[oe,N.height])*la,sa=ee?1:$a,Oe=ee?0:Math.max(0,(Ce.row-1)*la+(Ce.column-1)),ra=Me.flatMap(e=>Array.from({length:e.count||1},()=>e)),za=Math.ceil((ra.length+Oe)/sa),Aa=e=>{var r,n,o;return e!=null&&e.matched_alternate_unit_id?{...e,bar_code:(r=e==null?void 0:e.matched_bar_code)!=null?r:e==null?void 0:e.bar_code,auto_bar_code:(n=e==null?void 0:e.matched_bar_code)!=null?n:e==null?void 0:e.auto_bar_code,base_unit:e!=null&&e.matched_unit_name?{name:e.matched_unit_name}:e==null?void 0:e.base_unit,default_selling_price:(o=e==null?void 0:e.matched_selling_price)!=null?o:e==null?void 0:e.default_selling_price}:e},Fe=e=>{Me.some(r=>{var n,o;return r.id===e.id&&(((n=r.base_unit)==null?void 0:n.name)||r.base_unit)===(((o=e.base_unit)==null?void 0:o.name)||e.base_unit)})||Pe(r=>[...r,{...e,count:(e==null?void 0:e.quantity)||1}])},Ta=(e,r)=>{r<1||Pe(n=>n.map((o,d)=>d===e?{...o,count:r}:o))},La=e=>{Pe(r=>r.filter((n,o)=>o!==e))},Pa=()=>{window.confirm("Clear all items?")&&(Pe([]),y.show("Items cleared","success"))},_e=(e,r)=>{if(!e)return"";const n=new Date(e);if(isNaN(n.getTime()))return"";const o=String(n.getDate()).padStart(2,"0"),d=String(n.getMonth()+1).padStart(2,"0"),i=n.getFullYear(),t=["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"],x=["January","February","March","April","May","June","July","August","September","October","November","December"],b=t[n.getMonth()],m=x[n.getMonth()];switch(r){case"DD-MM-YYYY":return`${o}-${d}-${i}`;case"MM-DD-YYYY":return`${d}-${o}-${i}`;case"YYYY-MM-DD":return`${i}-${d}-${o}`;case"DD/MM/YYYY":return`${o}/${d}/${i}`;case"MM/DD/YYYY":return`${d}/${o}/${i}`;case"YYYY/MM/DD":return`${i}/${d}/${o}`;case"DD.MM.YYYY":return`${o}.${d}.${i}`;case"MMM DD, YYYY":return`${b} ${o}, ${i}`;case"DD MMM YYYY":return`${o} ${b} ${i}`;case"MM-YYYY":return`${d}-${i}`;case"MM/YYYY":return`${d}/${i}`;case"MMM YYYY":return`${b} ${i}`;case"MMMM YYYY":return`${m} ${i}`;case"YYYY-MM":return`${i}-${d}`;case"YYYY/MM":return`${i}/${d}`;case"YYYY":return`${i}`;default:return`${o}-${d}-${i}`}};c.exports.useEffect(()=>{!Te.current||Te.current.querySelectorAll("svg[data-barcode]").forEach(e=>{const r=e.getAttribute("data-barcode");!r||Va(e,r,{format:"CODE128",width:p==="elegant"?6:2,height:p==="elegant"?Math.max(24,u*7.2):Math.max(24,u*5.2),displayValue:Ae,fontSize:p==="elegant"?u*4:u+5,textMargin:2})})},[Me,ra.length,Ae,u,p,Q,de,oe,Ce.row,Ce.column,$e,N.width,N.height]);const Ba=async()=>{var e,r,n,o,d,i,t,x,b,m,L,P;try{if((g==null?void 0:g.from)&&(g==null?void 0:g.to)){const f=Number(g==null?void 0:g.from),M=Number(g==null?void 0:g.to);if(Number.isNaN(f)||Number.isNaN(M)||M<f){y.show(s("please enter proper value"),"warning");return}const v=await Z(oa(Ye.barcode_range,`barcode_from=${g==null?void 0:g.from}&barcode_to=${g==null?void 0:g.to}`));(n=(r=(e=v==null?void 0:v.payload)==null?void 0:e.data)==null?void 0:r.results)==null||n.forEach(O=>Fe(O)),((i=(d=(o=v==null?void 0:v.payload)==null?void 0:o.data)==null?void 0:d.results)==null?void 0:i.length)>0?y.show(s("item loaded successfully"),"success"):y.show(s("item not found within this range"),"warning")}else if(ea){const f=await Z(oa(Ye.barcode_range,`barcodes=${ea}`));(b=(x=(t=f==null?void 0:f.payload)==null?void 0:t.data)==null?void 0:x.results)==null||b.forEach(M=>Fe(Aa(M))),((P=(L=(m=f==null?void 0:f.payload)==null?void 0:m.data)==null?void 0:L.results)==null?void 0:P.length)>0?y.show(s("item loaded successfully"),"success"):y.show(s("item not found for provided barcodes"),"warning")}else{y.show(s("please fill the fields"),"warning");return}}catch{y.show(s("failed to fetch barcode"),"error")}},Ea=e=>({sales_est:s("estimate"),sales_order:s("sales order"),sales_invoice:s("invoice"),sales_return:s("sales return"),delivery_note:s("delivery note"),purchase_order:s("purchase order"),purchase_bill:s("purchase bills")})[e]||e;console.log("transactionDetails",Me);const ja=async()=>{var e,r;try{const n=Number(k.bill_no);if(!n||isNaN(n)){y.show("Invalid document number","warning");return}const o=await Z(ya(Ye.barcode_transaction,k)),d=((r=(e=o==null?void 0:o.payload)==null?void 0:e.data)==null?void 0:r.items)||[];d.forEach(i=>Fe(i)),y.show(d.length>0?"Items loaded":`No ${Ea(k.form_type)} Found For ${(k==null?void 0:k.vprefix)+(k==null?void 0:k.bill_no)}`,d.length>0?"success":"warning")}catch{y.show("Failed to load items","error")}},ma={classic:"Classic / Balanced (20x30)","price-focus":"Compliance Label (25x38)",compact:"Classic + Best Before (25x38)",elegant:"Detailed Label (40x60)"},Ra=async()=>{var e,r;try{const n={item_name:pe||!1,cost_price:wa||!1,arabic_name:F||!1,unit:E||!1,selling_price:ge||!1,barcode_text:Ae||!1,use_manual_barcode:Q||!1,cost_code:D||!1,note1:Y||!1,note2:z||!1,package_date:A||!1,expiry_date:T||!1,change_date_format:Re||!1,title_header:q||!1,inclusive:je||!1,show_border:Ee||!1,note1_text:R||"",note2_text:H||"",package_date_value:C||null,title_text:j||"",expiry_date_value:I,date_format_value:V},o=ma[p],d=["Classic / Balanced (20x30)","Compliance Label (25x38)","Classic + Best Before (25x38)","Detailed Label (40x60)"],i=(Ne==null?void 0:Ne.content)||{},x={...Object.fromEntries(Object.entries(i).filter(([m])=>d.includes(m))),[o]:n},b={settings:{...Ne,selected_style:o,label_template:{design_style:o},page:{page_type:$e,label_width:N.width,label_height:N.height,columns:de,rows:oe},margin:{top:w.top,right:w.right,bottom:w.bottom,left:w.left,font_size:u},content:x,cost_code_mapping:{0:_[0].value,1:_[1].value,2:_[2].value,3:_[3].value,4:_[4].value,5:_[5].value,6:_[6].value,7:_[7].value,8:_[8].value,9:_[9].value}}};if(ta)await Z(Za(Ye.barcode_preference,b,ta.toString())),y.show("Settings updated","success");else{const m=await Z(ya(Ye.barcode_preference,b));(r=(e=m==null?void 0:m.payload)==null?void 0:e.data)!=null&&r.id&&ua(m.payload.data.id),y.show("Settings saved","success")}}catch{y.show("Failed to save settings","error")}};c.exports.useEffect(()=>{(async()=>{var r,n,o,d,i,t,x,b,m,L,P,f,M,v,O,ae,te,le,se,re,we,Ue;try{const Le=await Z(oa(Ye.barcode_preference)),na=(r=Le==null?void 0:Le.payload)==null?void 0:r.data;if(!na)return;ua(na.id);const De=na.settings||{};if(De.content){Ca(De);const va=De.selected_style,h=((n=De.content)==null?void 0:n[va])||{};h.page&&(ne((o=h.page.page_type)!=null?o:"A4"),S({width:Number(h.page.label_width)||50,height:Number(h.page.label_height)||30}),ie((d=h.page.columns)!=null?d:""),ce((i=h.page.rows)!=null?i:"")),h.margin&&(B({top:(t=h.margin.top)!=null?t:6,right:(x=h.margin.right)!=null?x:6,bottom:(b=h.margin.bottom)!=null?b:6,left:(m=h.margin.left)!=null?m:6}),he(Number(h.margin.font_size)||7)),ue((L=h.item_name)!=null?L:!0),U((P=h.arabic_name)!=null?P:!1),me((f=h.selling_price)!=null?f:!0),ke((M=h.cost_price)!=null?M:!1),J((v=h.unit)!=null?v:!1),be((O=h.barcode_text)!=null?O:!0),X((ae=h.cost_code)!=null?ae:!1),fe((te=h.show_border)!=null?te:!1),$((le=h.note1)!=null?le:!1),W((se=h.note2)!=null?se:!1),G((re=h.package_date)!=null?re:!1),K((we=h.expiry_date)!=null?we:!1),xe((Ue=h.title_header)!=null?Ue:!1),We(h.title_text||""),Ge(h.note1_text||""),Ke(h.note2_text||""),qe(h.package_date_value||""),ia(h.expiry_date_value||""),Ze(h.use_manual_barcode||!1),Ve(h.change_date_format||!1),ve(h.inclusive||!1),Qe(h.date_format_value||"DD-MM-YYYY"),h.cost_code_mapping&&typeof h.cost_code_mapping=="object"&&ye(Object.entries(h.cost_code_mapping).map(([Ua,Ja])=>({number:Number(Ua),value:String(Ja||"?").slice(0,1).toUpperCase()})))}De.selected_style&&da({"Classic / Balanced (20x30)":"classic","Compliance Label (25x38)":"price-focus","Classic + Best Before (25x38)":"compact","Detailed Label (40x60)":"elegant"}[De.selected_style]||"classic")}catch(Le){console.error("Failed to load preferences",Le)}})()},[Z]);const Ha=e=>{switch(e){case"classic":he(7),S({width:30,height:20}),xe(!0),ue(!0),U(!1),me(!0),ke(!1),J(!1),be(!0),X(!0),fe(!0),$(!1),W(!1),G(!0),K(!0),ve(!1),ne("A4"),B({top:4,bottom:4,left:4,right:4}),ce(3),ie(4),ye(Array.from({length:10},(r,n)=>({number:n,value:String.fromCharCode(65+n)})));break;case"price-focus":he(6),S({width:38,height:25}),xe(!0),ue(!0),U(!1),me(!0),ke(!1),J(!1),be(!0),X(!0),fe(!0),$(!0),W(!0),G(!0),K(!0),ve(!1),ne("A4"),B({top:4,bottom:4,left:4,right:4}),ce(3),ie(4),ye(Array.from({length:10},(r,n)=>({number:n,value:String.fromCharCode(65+n)})));break;case"compact":he(7),S({width:38,height:25}),xe(!0),ue(!0),U(!1),me(!0),ke(!1),J(!1),be(!0),X(!0),fe(!0),$(!0),W(!0),G(!0),K(!0),ve(!1),ne("A4"),B({top:4,bottom:4,left:4,right:4}),ce(3),ie(4),ye(Array.from({length:10},(r,n)=>({number:n,value:String.fromCharCode(65+n)})));break;case"elegant":he(9),S({width:60,height:40}),xe(!0),ue(!0),U(!0),me(!0),ke(!1),J(!0),be(!0),X(!0),fe(!0),$(!0),W(!0),G(!0),K(!0),ve(!0),ne("A4"),B({top:4,bottom:4,left:4,right:4}),ce(3),ie(4),ye(Array.from({length:10},(r,n)=>({number:n,value:String.fromCharCode(65+n)})));break}},ba=e=>{var o;da(e);const r=ma[e],n=(o=Ne==null?void 0:Ne.content)==null?void 0:o[r];n?Ya(n):Ha(e)},Ia=()=>{if(!Te.current)return;const e=window.open("","","width=900,height=800");if(!e)return;const r=ee?"1fr":`repeat(${la}, ${N.width}mm)`,n=Oa(p);e.document.write(`
    <html>
      <head>
        <title>Print Barcodes</title>
        <style>
          @page {
            size: ${ee?`${N.width}mm ${N.height}mm`:Be.pageSize};
            margin: ${ee?"0":`${w.top}mm ${w.right}mm ${w.bottom}mm ${w.left}mm`};
          }

          body {
            margin: 0;
            font-family: Arial, Helvetica, sans-serif;
          }

          .page {
            display: grid;
            grid-template-columns: ${r};
            gap: 3mm;
            page-break-after: always;
            width: 100%;
          }

          .label {
            width: ${N.width}mm;
            height: ${N.height}mm;
            border: ${Ee?"1px dashed #777":"none"};
            box-sizing: border-box;
            page-break-inside: avoid;
            overflow: hidden;
            padding: ${ee?`${w.top}mm ${w.right}mm ${w.bottom}mm ${w.left}mm`:"2mm"};
            position: relative;
          }

          ${n}
        </style>
      </head>
      <body>
        ${Te.current.innerHTML}
      </body>
    </html>
  `),e.document.close(),e.focus(),e.print(),e.close()},Oa=e=>{switch(e){case"classic":return`
        .top-row {
          display: flex;
          justify-content: space-between;
          font-size: ${u}px;
        }

        .store {
          font-style: italic;
          font-weight: 600;
        }

        .barcode-row {
          display: flex;
          align-items: center;
        }

        .dates-row {
          display: flex;
          align-items: center;
          gap: 1px;
          margin-bottom: 1mm;
        }

        .code {
          writing-mode: vertical-rl;
          transform: rotate(180deg);
          font-size: 7px;
          font-weight: bold;
        }

        .barcode {
          height: 28px;
          width: 70%;
        }

        .item-name {
          font-size: ${u}px;
          width: 80%;
        }

        .rate {
          font-weight: bold;
          font-size: ${u}px;
        }

        .dates {
          position: absolute;
          right: 2mm;
          bottom: 2mm;
          font-size: 6px;
          text-align: right;
          writing-mode: vertical-rl;
          transform: rotate(180deg);
          display: flex;
          flex-direction: column;
          gap: 0.5mm;
        }

        .row-cost {
          display: flex;
          flex-direction: row;
          justify-content: space-between;
          align-items: center;
          width: 80%;
        }
      `;case"price-focus":return`
        .price-focus-label {
          width: 80%;
          height: 100%;
          font-family: Arial, sans-serif;
          box-sizing: border-box;
          display: flex;
          flex-direction: column;
          justify-content: flex-start;
          font-size: ${u}px;
          line-height: 1.1;
        }

        /* Header */
        .pf-header {
          text-align: center;
          margin-bottom: 1mm;
        }

        .pf-company {
          font-weight: bold;
          font-size: ${u}px;
          margin-bottom: 1mm;
        }

        .pf-location {
          font-size: ${u}px;
          font-weight: 600;
        }

        /* Item name (right aligned like image) */
        .pf-item-name {
          text-align: right;
          font-size: ${u}px;
          font-weight: bold;
        }

        /* Price */
        .price {
          text-align: center;
          font-weight: bold;
          font-size: ${u}px;
          margin: 0.5mm 0;
        }

        /* Note */
        .pf-note {
          text-align: center;
          font-size: ${u}px;
          margin-top: 0.5mm;
        }

        .dates {
          position: absolute;
          right: 2mm;
          bottom: 2mm;
          font-size: 6px;
          text-align: right;
          writing-mode: vertical-rl;
          transform: rotate(180deg);
          display: flex;
          flex-direction: column;
          gap: 0.5mm;
        }

        .barcode-row {
          display: flex;
          align-items: center;
        }

        .code {
          writing-mode: vertical-rl;
          transform: rotate(180deg);
          font-size: 7px;
          font-weight: bold;
        }

        .barcode {
          height: 28px;
          width: 90%;
        }

        .dates-row {
          display: flex;
          align-items: center;
          gap: 1px;
        }

        .row-cost {
          display: flex;
          flex-direction: row;
          justify-content: space-between;
          align-items: center;
          width: 80%;
        }
      `;case"compact":return`
        .compact-label {
          width: 80%;
          height: 100%;
          display: flex;
          flex-direction: column;
          font-size: ${u}px;
          line-height: 1.1;
        }

        .cmp-header {
          text-align: center;
        }

        .cmp-store {
          font-weight: 800;
          font-size: ${u+1}px;
        }

        .cmp-location {
          font-weight: 700;
        }

        .cmp-license {
          font-size: ${u-1}px;
        }

        .barcode-row {
          display: flex;
          align-items: center;
        }

        .code {
          writing-mode: vertical-rl;
          transform: rotate(180deg);
          font-size: 7px;
          font-weight: bold;
        }

        .barcode {
          height: 28px;
          width: 90%;
        }

        .dates {
          position: absolute;
          right: 2mm;
          bottom: 2mm;
          font-size: 6px;
          writing-mode: vertical-rl;
          transform: rotate(180deg);
          display: flex;
          flex-direction: column;
          gap: 0.5mm;
        }

        .dates-row {
          display: flex;
          align-items: center;
          gap: 1px;
        }

        .expiry-row {
          display: flex;
          gap: 1px;
        }

        .price {
          font-weight: bold;
          font-size: ${u+1}px;
        }

        .cmp-category {
          font-weight: 700;
          margin-top: 0.5mm;
        }

        .barcode {
          height: 26px;
          width: 80%;
        }

        .row-cost {
          display: flex;
          flex-direction: row;
          justify-content: space-between;
          align-items: center;
          width: 80%;
        }
      `;case"elegant":return`
        .retail-label {
          width: 100%;
          height: 100%;
          display: flex;
          flex-direction: column;
          font-size: ${u}px;
          line-height: 1.15;
        }

        .rl-header {
          text-align: center;
          display: flex;
          flex-direction: column;
          gap: 0.5mm;
        }

        .rl-company {
          font-weight: 800;
          font-size: ${u+2}px;
        }

        .rl-tagline {
          font-weight: 700;
        }

        .rl-address,
        .rl-contact {
          font-size: ${u-1}px;
        }

        .rl-barcode-section {
          text-align: center;
          margin: 0.5mm 0;
        }

        .barcode {
          height: 28px;
          width: 95%;
        }

        .rl-barcode-text {
          font-size: ${u-1}px;
          margin-top: 1px;
        }

        .rl-details {
          display: flex;
          justify-content: space-between;
          margin-top: 1mm;
        }

        .rl-left {
          text-align: left;
        }

        .rl-right {
          text-align: right;
          font-size: 7px;
          display: flex;
          flex-direction: column;
          gap: 0.5mm;
        }

        .rl-code {
          font-weight: 700;
        }

        .rl-name {
          font-weight: 800;
          margin: 1px 0;
        }

        .rl-price-row {
          margin-top: auto;
          font-weight: bold;
          font-size: ${u+3}px;
          display: flex;
          align-items: center;
          gap: 4px;
        }

        .rl-price-label {
          font-weight: bold;
        }

        .rl-price-value {
          font-weight: bold;
        }

        .rl-tax {
          font-size: ${u-2}px;
        }

        .rl-name-ar {
          direction: rtl;
          text-align: right;
          font-family: "Tahoma", "Arial", sans-serif;
          font-weight: 700;
        }

        .row-cost {
          display: flex;
          flex-direction: row;
          justify-content: space-between;
          align-items: center;
          width: 80%;
        }
      `;default:return""}};function Fa(e,r){const n=new Date(e),d=new Date(r).getTime()-n.getTime();return`Best Before ${Math.ceil(d/(1e3*60*60*24))} Days from Pkd Dt.`}return l("div",{className:"mt-5 px-5 w-full mx-auto overflow-auto h-full pb-20",children:[l("div",{className:"sticky top-0 z-10 bg-white pb-4 border-b",children:[a("h2",{className:"text-xl font-bold mb-5",children:s("barcode printing")}),a("div",{className:"flex border-b mb-6",children:["items","settings"].map(e=>a("button",{onClick:()=>Na(e),className:`px-6 py-3 font-medium ${Xe===e?"border-b-2 border-blue-600 text-blue-700":"text-gray-500 hover:text-gray-700"}`,children:e==="items"?s("items"):s("settings")},e))})]}),Xe==="items"&&l(Je,{children:[l("div",{className:"grid grid-cols-1 md:grid-cols-3 gap-6 mb-6",children:[l("div",{className:"border rounded-lg p-4 bg-white shadow-sm",children:[l("div",{className:"grid grid-cols-2 gap-4 mb-3",children:[l("div",{children:[a("label",{className:"block text-sm text-gray-600 mb-1",children:s("auto barcode from")}),a("input",{type:"text",value:g.from,onChange:e=>pa(r=>({...r,from:Number(e.target.value)})),className:"w-full border rounded-md px-3 py-2 text-sm"})]}),l("div",{children:[l("label",{className:"block text-sm text-gray-600 mb-1",children:[s("auto barcode to")," "]}),a("input",{type:"text",value:g.to,onChange:e=>pa(r=>({...r,to:Number(e.target.value)})),className:"w-full border rounded-md px-3 py-2 text-sm"})]})]}),l("div",{className:"mb-3",children:[a("label",{className:"block text-sm text-gray-600 mb-1",children:s("barcode comma separated")}),a("input",{type:"text",value:ea,onChange:e=>Ma(e.target.value),placeholder:"12345,67890,...",className:"w-full border rounded-md px-3 py-2 text-sm"})]}),a("div",{className:"flex justify-end",children:a("button",{onClick:Ba,className:"px-4 py-2 bg-gray-100 border rounded-md text-sm hover:bg-gray-200",children:s("load")})})]}),l("div",{className:"border rounded-lg p-4 bg-white shadow-sm",children:[l("div",{className:"grid grid-cols-2 gap-4 mb-3",children:[l("div",{children:[a("label",{className:"block text-sm text-gray-600 mb-1",children:s("vprefix")}),a("input",{type:"text",value:k.vprefix,onChange:e=>aa(r=>({...r,vprefix:e.target.value})),className:"w-full border rounded-md px-3 py-2 text-sm"})]}),l("div",{children:[a("label",{className:"block text-sm text-gray-600 mb-1",children:s("type")}),l("select",{value:k.form_type,onChange:e=>aa(r=>({...r,form_type:e.target.value})),className:"w-full border rounded-md px-3 py-2 text-sm",children:[a("option",{value:"sales_est",children:s("estimate")}),a("option",{value:"sales_order",children:s("sales order")}),a("option",{value:"sales_invoice",children:s("invoice")}),a("option",{value:"sales_return",children:s("sales return")}),a("option",{value:"delivery_note",children:s("delivery note")}),a("option",{value:"purchase_order",children:s("purchase order")}),a("option",{value:"purchase_bill",children:s("purchase bills")})]})]})]}),l("div",{className:"grid grid-cols-2 gap-4 mb-3",children:[l("div",{children:[a("label",{className:"block text-sm text-gray-600 mb-1",children:s("doc no")}),a("input",{type:"text",value:k.bill_no,onChange:e=>aa(r=>({...r,bill_no:e.target.value})),className:"w-full border rounded-md px-3 py-2 text-sm"})]}),a("div",{className:"flex items-end justify-end",children:a("button",{onClick:ja,className:"px-4 py-2 bg-gray-100 border rounded-md text-sm hover:bg-gray-200",children:s("load")})})]})]}),!ee&&a("div",{className:"border rounded-lg p-4 bg-white shadow-sm",children:l("div",{className:"grid grid-cols-2 gap-4 mb-3",children:[l("div",{children:[a("label",{className:"block text-sm text-gray-600 mb-1",children:s("start row")}),a("input",{type:"number",min:1,value:Ce.row,onChange:e=>ca(r=>({...r,row:Math.max(1,Number(e.target.value))})),className:"w-full border rounded-md px-3 py-2 text-sm"})]}),l("div",{children:[a("label",{className:"block text-sm text-gray-600 mb-1",children:s("start col")}),a("input",{type:"number",min:1,value:Ce.column,onChange:e=>ca(r=>({...r,column:Math.max(1,Number(e.target.value))})),className:"w-full border rounded-md px-3 py-2 text-sm"})]})]})})]}),a(Qa,{noLabel:!0,handleAddItem:Fe,field:{showStockInfo:!0,showRateInfo:!0},className:"w-full bg-white border rounded mb-5 p-3",hasCreateButton:!0}),Me.length>0?l(Je,{children:[a("div",{className:"overflow-x-auto mb-5",children:l("table",{className:"w-full text-sm border-collapse",children:[a("thead",{className:"bg-gray-100",children:l("tr",{children:[a("th",{className:"border p-3 text-left",children:"#"}),a("th",{className:"border p-3 text-left",children:s("item")}),a("th",{className:"border p-3 text-left",children:s("barcode")}),a("th",{className:"border p-3 text-left",children:s("unit")}),a("th",{className:"border p-3 text-left",children:s("price")}),a("th",{className:"border p-3 text-center",children:s("copies")}),a("th",{className:"border p-3 text-center w-20",children:"\xD7"})]})}),a("tbody",{children:Me.map((e,r)=>{var n;return l("tr",{className:"hover:bg-gray-50",children:[a("td",{className:"border p-3",children:r+1}),a("td",{className:"border p-3",children:e.name}),a("td",{className:"border p-3 font-mono",children:Q?(e==null?void 0:e.bar_code)||(e==null?void 0:e.auto_bar_code)||"":(e==null?void 0:e.auto_bar_code)||""}),a("td",{className:"border p-3 font-mono",children:((n=e==null?void 0:e.base_unit)==null?void 0:n.name)||(e==null?void 0:e.base_unit)||"\u2014"}),a("td",{className:"border p-3",children:e.default_selling_price!=null?`${Se} ${e.default_selling_price}`:"\u2014"}),a("td",{className:"border p-3 text-center",children:a("input",{type:"number",min:1,value:e.count,onChange:o=>Ta(r,+o.target.value),className:"w-20 mx-auto border rounded px-2 py-1 text-center"})}),a("td",{className:"border p-3 text-center",children:a("button",{onClick:()=>La(r),className:"text-red-600 hover:text-red-800",children:"\xD7"})})]},e.id)})})]})}),l("div",{className:"flex items-center gap-4",children:[a("button",{onClick:Ia,className:"px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700",children:s("print barcodes")}),a("button",{onClick:Pa,className:"px-6 py-3 bg-red-50 text-red-700 border border-red-200 rounded-lg hover:bg-red-100",children:s("clear all")})]})]}):a("p",{className:"text-gray-500 text-center py-10",children:s("no items added yet. use search or inputs above.")})]}),Xe==="settings"&&l("div",{className:"space-y-6",children:[l("section",{className:"border rounded-lg p-5 bg-white shadow-sm",children:[l("div",{className:"flex justify-between items-center mb-4",children:[a("h3",{className:"font-semibold text-lg",children:s("label template")}),l("button",{type:"button",onClick:()=>ze(!0),className:"flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-blue-600 bg-blue-50 hover:bg-blue-100 hover:text-blue-800 transition-colors rounded-lg border border-blue-100 shadow-sm",children:[a("svg",{xmlns:"http://www.w3.org/2000/svg",fill:"none",viewBox:"0 0 24 24",strokeWidth:2,stroke:"currentColor",className:"w-4 h-4",children:a("path",{strokeLinecap:"round",strokeLinejoin:"round",d:"M9.879 7.519c1.171-1.025 3.071-1.025 4.242 0 1.172 1.025 1.172 2.687 0 3.712-.203.179-.43.326-.67.442-.745.361-1.45.999-1.45 1.827v.75M21 12a9 9 0 11-18 0 9 9 0 0118 0zm-9 5.25h.008v.008H12v-.008z"})}),s("template guidelines")]})]}),l("div",{children:[a("label",{className:"block text-sm font-medium mb-1",children:s("design style")}),l("select",{value:p,onChange:e=>{ba(e.target.value)},className:"w-full border rounded px-3 py-2",children:[a("option",{value:"classic",children:s("1. classic / balanced (20X30)")}),a("option",{value:"price-focus",children:s("2. compliance label (25X38)")}),a("option",{value:"compact",children:s("3. classic + best before (25X38)")}),a("option",{value:"elegant",children:s("4. detailed label (40X60)")})]}),l("p",{className:"text-xs text-gray-500 mt-1",children:[p==="classic"&&s("Traditional layout \u2022 name + price + barcode \u2022 most common"),p==="price-focus"&&s("Large prominent price \u2022 promotional / retail aggressive style"),p==="compact"&&s("Very dense \u2022 expiry & batch emphasized \u2022 small thermal labels"),p==="elegant"&&s("Premium look \u2022 bigger fonts & spacing \u2022 gifts / boutique / branded")]})]})]}),l("section",{className:"border rounded-lg p-5 bg-white shadow-sm",children:[a("h3",{className:"font-semibold text-lg mb-4",children:s("page & layout")}),l("div",{className:"grid grid-cols-1 md:grid-cols-3 gap-5",children:[l("div",{children:[l("label",{className:"block text-sm font-medium mb-1",children:[s("page type")," ",$e!=="A4"&&"- (Recommended margin: 2, font size: 7)"]}),l("select",{value:$e,onChange:e=>{const r=e.target.value;ne(r),r==="THERMAL_50_30"?(S({width:50,height:30}),B({top:2,bottom:2,left:2,right:2})):r==="THERMAL_40_25"?(S({width:40,height:25}),B({top:2,bottom:2,left:2,right:2})):r==="A4"&&(S({width:38,height:25}),B({top:6,bottom:6,left:6,right:6}))},className:"w-full border rounded px-3 py-2",children:[a("option",{value:"A4",children:"A4 Sheet"}),a("option",{value:"THERMAL_50_30",children:"Thermal 50\xD730 mm"}),a("option",{value:"THERMAL_40_25",children:"Thermal 40\xD725 mm"})]})]}),l("div",{children:[a("label",{className:"block text-sm font-medium mb-1",children:s("label height (mm)")}),a("input",{type:"number",value:N.height,onChange:e=>S(r=>({...r,height:+e.target.value})),className:"w-full border rounded px-3 py-2"})]}),l("div",{children:[a("label",{className:"block text-sm font-medium mb-1",children:s("label width (mm)")}),a("input",{type:"number",value:N.width,onChange:e=>S(r=>({...r,width:+e.target.value})),className:"w-full border rounded px-3 py-2"})]}),!ee&&l(Je,{children:[l("div",{children:[a("label",{className:"block text-sm font-medium mb-1",children:s("columns (override)")}),a("input",{type:"number",placeholder:"auto",value:de||"",onChange:e=>ie(e.target.value?+e.target.value:""),className:"w-full border rounded px-3 py-2"})]}),l("div",{children:[a("label",{className:"block text-sm font-medium mb-1",children:s("rows (override)")}),a("input",{type:"number",placeholder:"auto",value:oe||"",onChange:e=>ce(e.target.value?+e.target.value:""),className:"w-full border rounded px-3 py-2"})]})]})]})]}),l("section",{className:"border rounded-lg p-5 bg-white shadow-sm",children:[a("h3",{className:"font-semibold text-lg mb-4",children:s("margins & font")}),l("div",{className:"grid grid-cols-2 md:grid-cols-5 gap-4",children:[["top","right","bottom","left"].map(e=>l("div",{children:[l("label",{className:"block text-sm capitalize mb-1",children:[s(e)," (mm)"]}),a("input",{type:"number",value:w[e],onChange:r=>B(n=>({...n,[e]:Math.max(0,+r.target.value)})),className:"w-full border rounded px-3 py-2"})]},e)),l("div",{children:[a("label",{className:"block text-sm mb-1",children:s("font size (px)")}),a("input",{type:"number",min:6,max:18,value:u,onChange:e=>he(+e.target.value),className:"w-full border rounded px-3 py-2"})]})]})]}),l("section",{className:"border rounded-lg p-5 bg-white shadow-sm",children:[a("h3",{className:"font-semibold text-lg mb-4",children:s("label content")}),l("div",{className:"grid grid-cols-2 md:grid-cols-3 gap-x-8 gap-y-3 mb-6",children:[l("label",{className:"flex items-center gap-2",children:[a("input",{type:"checkbox",checked:pe,onChange:()=>ue(!pe)}),s("item name")]}),p!=="price-focus"&&l("label",{className:"flex items-center gap-2",children:[a("input",{type:"checkbox",checked:F,onChange:()=>U(!F)}),s("arabic name")]}),l("label",{className:"flex items-center gap-2",children:[a("input",{type:"checkbox",checked:ge,onChange:()=>me(!ge)}),s("selling price")]}),!["classic","price-focus","compact"].includes(p)&&l("label",{className:"flex items-center gap-2",children:[a("input",{type:"checkbox",checked:E,onChange:()=>J(!E),disabled:["classic","price-focus","compact"].includes(p)&&D}),s("unit")]}),l("label",{className:"flex items-center gap-2",children:[a("input",{type:"checkbox",checked:Ae,onChange:()=>be(!Ae)}),s("barcode text")]}),l("label",{className:"flex items-center gap-2",children:[a("input",{type:"checkbox",checked:Q,onChange:()=>Ze(!Q)}),s("use manual barcode")]}),!["classic","price-focus","compact"].includes(p)&&l("label",{className:"flex items-center gap-2",children:[a("input",{type:"checkbox",checked:D,onChange:()=>X(!D),disabled:["classic","price-focus","compact"].includes(p)&&E}),s("cost code")]}),l("label",{className:"flex items-center gap-2",children:[a("input",{type:"checkbox",checked:Ee,onChange:()=>fe(!Ee)}),s("border")]}),p!=="classic"&&l(Je,{children:[p!=="price-focus"&&l("label",{className:"flex items-center gap-2",children:[a("input",{type:"checkbox",checked:Y,onChange:()=>$(!Y)}),s("note 1")]}),l("label",{className:"flex items-center gap-2",children:[a("input",{type:"checkbox",checked:z,onChange:()=>W(!z),disabled:p==="price-focus"}),s("note 2")]}),l("label",{className:"flex items-center gap-2",children:[a("input",{type:"checkbox",checked:A,onChange:()=>G(!A)}),s("package date")]}),l("label",{className:"flex items-center gap-2",children:[a("input",{type:"checkbox",checked:T,onChange:()=>K(!T)}),s("expiry date")]})]}),l("label",{className:"flex items-center gap-2",children:[a("input",{type:"checkbox",checked:q,onChange:()=>xe(!q)}),s("title / header")]}),l("label",{className:"flex items-center gap-2",children:[a("input",{type:"checkbox",checked:je,onChange:()=>ve(!je),disabled:["classic","price-focus","compact"].includes(p)}),s("inclusive")]}),l("label",{className:"flex items-center gap-2",children:[a("input",{type:"checkbox",checked:Re,onChange:()=>Ve(!Re)}),s("change date format")]})]}),l("div",{className:"grid grid-cols-2 md:grid-cols-3 gap-x-8 gap-y-3 mb-6",children:[["classic","price-focus","compact"].includes(p)&&l("div",{className:"col-span-2 md:col-span-1 border rounded-lg p-3 bg-gray-50",children:[l("div",{className:"space-y-2",children:[l("label",{className:"flex items-center gap-2",children:[a("input",{type:"checkbox",checked:E,onChange:()=>{J(!E),X(!1)}}),s("unit")]}),l("label",{className:"flex items-center gap-2",children:[a("input",{type:"checkbox",checked:D,onChange:()=>{X(!D),J(!1)}}),s("cost code")]})]}),a("p",{className:"text-xs text-gray-500 mt-2",children:s("only one option can be selected")})]}),p=="classic"&&l("div",{className:"col-span-2 md:col-span-1 border rounded-lg p-3 bg-gray-50",children:[l("div",{className:"space-y-2",children:[l("label",{className:"flex items-center gap-2",children:[a("input",{type:"checkbox",checked:A,onChange:()=>{G(!A),$(!1)}}),s("package date")]}),l("label",{className:"flex items-center gap-2",children:[a("input",{type:"checkbox",checked:Y,onChange:()=>{$(!Y),G(!1)}}),s("note 1")]})]}),a("p",{className:"text-xs text-gray-500 mt-2",children:s("only one option can be selected")})]}),p==="classic"&&l("div",{className:"col-span-2 md:col-span-1 border rounded-lg p-3 bg-gray-50",children:[l("div",{className:"space-y-2",children:[l("label",{className:"flex items-center gap-2",children:[a("input",{type:"checkbox",checked:T,onChange:()=>{K(!T),W(!1)}}),s("expiry date")]}),l("label",{className:"flex items-center gap-2",children:[a("input",{type:"checkbox",checked:z,onChange:()=>{W(!z),K(!1)}}),s("note 2")]})]}),a("p",{className:"text-xs text-gray-500 mt-2",children:s("only one option can be selected")})]}),p==="price-focus"&&l("div",{className:"col-span-2 md:col-span-1 border rounded-lg p-3 bg-gray-50",children:[l("div",{className:"space-y-2",children:[l("label",{className:"flex items-center gap-2",children:[a("input",{type:"checkbox",checked:F,onChange:()=>{U(!F),$(!1)}}),s("arabic name")]}),l("label",{className:"flex items-center gap-2",children:[a("input",{type:"checkbox",checked:Y,onChange:()=>{$(!Y),U(!1)}}),s("note 1")]})]}),a("p",{className:"text-xs text-gray-500 mt-2",children:s("only one option can be selected")})]})]}),q&&l("div",{className:"mt-4",children:[a("label",{className:"block text-sm font-medium mb-1",children:s("title text")}),a("input",{type:"text",value:j,onChange:e=>We(e.target.value),placeholder:s("e.g. abc trading"),className:"w-full border rounded px-3 py-2",maxLength:60})]}),l("div",{className:"mt-6 grid grid-cols-1 md:grid-cols-2 gap-5",children:[Y&&l("div",{children:[a("label",{className:"block text-sm mb-1",children:s("note 1")}),a("input",{value:R,onChange:e=>Ge(e.target.value),className:"w-full border rounded px-3 py-2",placeholder:s("e.g. keep in cool & dry place")})]}),z&&l("div",{children:[a("label",{className:"block text-sm mb-1",children:s("note 2")}),a("input",{value:H,onChange:e=>Ke(e.target.value),className:"w-full border rounded px-3 py-2"})]}),A&&l("div",{children:[a("label",{className:"block text-sm mb-1",children:s("package date")}),a("input",{type:"date",value:C,onChange:e=>qe(e.target.value),className:"w-full border rounded px-3 py-2"})]}),T&&l("div",{children:[a("label",{className:"block text-sm mb-1",children:s("expiry date")}),a("input",{type:"date",value:I,onChange:e=>ia(e.target.value),className:"w-full border rounded px-3 py-2"})]}),Re&&l("div",{children:[a("label",{className:"block text-sm mb-1",children:s("date format")}),l("select",{value:V,onChange:e=>Qe(e.target.value),className:"w-full border rounded px-3 py-2 bg-white",children:[a("option",{value:"DD-MM-YYYY",children:"DD-MM-YYYY"}),a("option",{value:"MM-DD-YYYY",children:"MM-DD-YYYY"}),a("option",{value:"YYYY-MM-DD",children:"YYYY-MM-DD"}),a("option",{value:"DD/MM/YYYY",children:"DD/MM/YYYY"}),a("option",{value:"MM/DD/YYYY",children:"MM/DD/YYYY"}),a("option",{value:"YYYY/MM/DD",children:"YYYY/MM/DD"}),a("option",{value:"DD.MM.YYYY",children:"DD.MM.YYYY"}),a("option",{value:"MMM DD, YYYY",children:"MMM DD, YYYY"}),a("option",{value:"DD MMM YYYY",children:"DD MMM YYYY"}),a("option",{value:"MM-YYYY",children:"MM-YYYY"}),a("option",{value:"MM/YYYY",children:"MM/YYYY"}),a("option",{value:"MMM YYYY",children:"MMM YYYY"}),a("option",{value:"MMMM YYYY",children:"MMMM YYYY"}),a("option",{value:"YYYY-MM",children:"YYYY-MM"}),a("option",{value:"YYYY/MM",children:"YYYY/MM"}),a("option",{value:"YYYY",children:"YYYY"})]})]})]})]}),D&&l("section",{className:"border rounded-lg p-5 bg-white shadow-sm",children:[a("h3",{className:"font-semibold text-lg mb-4",children:s("cost code mapping (0\u20139)")}),a("div",{className:"flex flex-wrap gap-4 justify-center",children:_.map((e,r)=>l("div",{className:"flex flex-col items-center",children:[a("div",{className:"w-10 h-10 flex items-center justify-center bg-gray-100 rounded font-bold mb-2",children:e.number}),a("input",{type:"text",maxLength:1,value:e.value,onChange:n=>ha(r,n.target.value),className:"w-12 text-center border rounded py-1.5 text-lg font-bold",onFocus:n=>n.target.select(),onBlur:n=>{n.target.value||ha(r,"_")}})]},e.number))})]}),a("div",{className:"flex justify-end",children:a("button",{onClick:Ra,className:"bg-blue-600 text-white px-6 py-2.5 rounded hover:bg-blue-700",children:ta?s("update settings"):s("save settings")})})]}),a("div",{ref:Te,style:{display:"none"},children:Array.from({length:za},(e,r)=>{const n=r*sa-(r===0?Oe:0),o=n+sa,d=ra.slice(Math.max(0,n),o),i=r===0&&Oe>0?[...Array(Oe).fill(null),...d]:d;return a("div",{className:"page",children:i.map((t,x)=>{var b,m,L,P,f,M,v,O,ae,te,le,se,re,we;return t?l("div",{className:"label",children:[p==="classic"&&l("div",{className:"classic-label",children:[q&&j&&a("div",{className:"top-row",children:a("span",{className:"store",children:j})}),l("div",{className:"barcode-row",children:[a("span",{className:"code",children:(t==null?void 0:t.item_code)||""}),a("svg",{className:"barcode","data-barcode":Q?(t==null?void 0:t.bar_code)||(t==null?void 0:t.auto_bar_code)||"":(t==null?void 0:t.auto_bar_code)||""})]}),pe&&a("div",{className:"item-name",children:t==null?void 0:t.name}),F&&a("div",{className:"item-name",children:t==null?void 0:t.name_in_secondary_lang}),l("div",{className:"row-cost",children:[ge&&t.default_selling_price!=null&&l("div",{className:"rate",children:[Se," ",t.default_selling_price]}),D&&((b=t==null?void 0:t.cost_price)!=null?b:t==null?void 0:t.default_purchase_price)&&a("div",{className:"rate",children:Ie(Math.floor((m=t==null?void 0:t.cost_price)!=null?m:t==null?void 0:t.default_purchase_price),He)}),E&&(((L=t==null?void 0:t.base_unit)==null?void 0:L.name)||(t==null?void 0:t.base_unit)||"\u2014")&&a("div",{className:"rate",children:((P=t==null?void 0:t.base_unit)==null?void 0:P.name)||(t==null?void 0:t.base_unit)||"\u2014"})]}),l("div",{className:"dates",children:[A&&l("div",{className:"dates-row",children:[a("div",{children:"PKD DT:"}),C&&a("div",{children:_e(C,V)})]}),T&&l("div",{className:"dates-row",children:[a("div",{children:"EXP DT:"}),I&&a("div",{children:_e(I,V)})]}),!A&&Y&&R&&a("div",{className:"dates-row",children:a("div",{children:R})}),!T&&z&&H&&a("div",{className:"dates-row",children:a("div",{children:H})})]})]}),p==="price-focus"&&l("div",{className:"price-focus-label",children:[l("div",{className:"pf-header",children:[q&&j&&a("div",{className:"pf-company",children:j}),Y&&R&&a("div",{className:"pf-location",children:R})]}),pe&&(t==null?void 0:t.name)&&a("div",{className:"pf-item-name",children:t.name}),F&&(t==null?void 0:t.name_in_secondary_lang)&&a("div",{className:"pf-item-name",children:t.name_in_secondary_lang}),l("div",{className:"barcode-row",children:[a("span",{className:"code",children:(t==null?void 0:t.item_code)||""}),a("svg",{className:"barcode","data-barcode":Q?(t==null?void 0:t.bar_code)||(t==null?void 0:t.auto_bar_code)||"":(t==null?void 0:t.auto_bar_code)||""})]}),l("div",{className:"row-cost",children:[ge&&t.default_selling_price!=null&&l("div",{className:"price",children:[Se," ",t.default_selling_price]}),D&&((f=t==null?void 0:t.cost_price)!=null?f:t==null?void 0:t.default_purchase_price)&&a("div",{className:"price",children:Ie(Math.floor((M=t==null?void 0:t.cost_price)!=null?M:t==null?void 0:t.default_purchase_price),He)}),E&&(((v=t==null?void 0:t.base_unit)==null?void 0:v.name)||(t==null?void 0:t.base_unit)||"\u2014")&&a("div",{className:"price",children:((O=t==null?void 0:t.base_unit)==null?void 0:O.name)||(t==null?void 0:t.base_unit)||"\u2014"})]}),z&&H&&a("div",{className:"pf-note",children:H}),l("div",{className:"dates",children:[A&&l("div",{className:"dates-row",children:[a("div",{children:"PKD DT:"}),C&&a("div",{children:_e(C,V)})]}),T&&l("div",{className:"dates-row",children:[a("div",{children:"EXP DT:"}),I&&a("div",{children:_e(I,V)})]})]})]}),p==="compact"&&l("div",{className:"compact-label",children:[l("div",{className:"cmp-header",children:[q&&j&&a("div",{className:"cmp-store",children:j}),Y&&R&&a("div",{className:"cmp-location",children:R}),z&&H&&a("div",{className:"cmp-license",children:H})]}),l("div",{className:"barcode-row",children:[a("span",{className:"code",children:(t==null?void 0:t.item_code)||""}),a("svg",{className:"barcode","data-barcode":Q?(t==null?void 0:t.bar_code)||(t==null?void 0:t.auto_bar_code)||"":(t==null?void 0:t.auto_bar_code)||""})]}),l("div",{className:"row-cost",children:[ge&&t.default_selling_price!=null&&l("div",{className:"price",children:[Se," ",t.default_selling_price]}),D&&((ae=t==null?void 0:t.cost_price)!=null?ae:t==null?void 0:t.default_purchase_price)&&a("div",{className:"price",children:Ie(Math.floor((te=t==null?void 0:t.cost_price)!=null?te:t==null?void 0:t.default_purchase_price),He)}),E&&(((le=t==null?void 0:t.base_unit)==null?void 0:le.name)||(t==null?void 0:t.base_unit)||"\u2014")&&a("div",{className:"price",children:((se=t==null?void 0:t.base_unit)==null?void 0:se.name)||(t==null?void 0:t.base_unit)||"\u2014"})]}),pe&&a("div",{className:"item-name",style:{margin:"1px 0"},children:t.name}),F&&t.name_in_secondary_lang&&a("div",{className:"name",style:{margin:"1px 0"},children:t.name_in_secondary_lang}),l("div",{className:"dates",children:[A&&l("div",{className:"dates-row",children:[a("div",{children:"PKD DT:"}),C&&a("div",{children:_e(C,V)})]}),a("div",{className:"expiry-row",children:T&&C&&I&&a("div",{children:Fa(C,I)})})]})]}),p==="elegant"&&l("div",{className:"retail-label",children:[(q||Y||z)&&l("div",{className:"rl-header",children:[q&&j&&a("div",{className:"rl-company",children:j}),Y&&R&&a("div",{className:"rl-address",children:R}),z&&H&&a("div",{className:"rl-tagline",children:H})]}),a("div",{className:"rl-barcode-section",children:a("svg",{"data-barcode":Q?(t==null?void 0:t.bar_code)||(t==null?void 0:t.auto_bar_code)||"":(t==null?void 0:t.auto_bar_code)||"",className:"barcode"})}),l("div",{className:"rl-details",children:[l("div",{className:"rl-left",children:[a("div",{className:"rl-code",children:(t==null?void 0:t.item_code)||""}),pe&&a("div",{className:"rl-name",style:{margin:"3px 0"},children:t.name}),F&&(t==null?void 0:t.name_in_secondary_lang)&&a("div",{className:"rl-name-ar",style:{margin:"3px 0"},children:t==null?void 0:t.name_in_secondary_lang})]}),l("div",{className:"rl-right",children:[A&&C&&l("div",{children:["PKD DT: ",_e(C,V)]}),T&&I&&l("div",{children:["EXP DT: ",_e(I,V)]}),E&&a("div",{className:"rl-code",children:"PCS"})]})]}),l("div",{className:"row-cost",style:{margin:"3px 0"},children:[ge&&t.default_selling_price!=null&&a("div",{className:"rl-price-row",children:l("span",{className:"rl-price-value",children:[Se," ",t.default_selling_price]})}),D&&((re=t==null?void 0:t.cost_price)!=null?re:t==null?void 0:t.default_purchase_price)&&a("div",{className:"rl-price-value",children:Ie(Math.floor((we=t==null?void 0:t.cost_price)!=null?we:t==null?void 0:t.default_purchase_price),He)})]}),je&&l("div",{className:"rl-tax",children:["(",s("inclusive of all taxes"),")"]})]})]},x):a("div",{className:"label"},x)})},r)})}),_a&&a("div",{className:"fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm transition-opacity duration-300",onClick:()=>ze(!1),children:l("div",{className:"bg-white rounded-2xl shadow-2xl max-w-4xl w-full overflow-hidden border border-gray-100 transform scale-100 transition-all duration-300 flex flex-col max-h-[90vh]",onClick:e=>e.stopPropagation(),children:[l("div",{className:"bg-gradient-to-r from-blue-600 to-indigo-700 p-6 text-white flex justify-between items-center",children:[l("div",{children:[a("h3",{className:"text-xl font-bold",children:s("template guidelines & preferred settings")}),a("p",{className:"text-blue-100 text-sm mt-1",children:s("recommended configuration details to ensure perfect alignment and readability.")})]}),a("button",{onClick:()=>ze(!1),className:"text-white/80 hover:text-white hover:bg-white/10 p-2 rounded-full transition-colors","aria-label":"Close",children:a("svg",{className:"w-6 h-6",fill:"none",viewBox:"0 0 24 24",stroke:"currentColor",strokeWidth:2,children:a("path",{strokeLinecap:"round",strokeLinejoin:"round",d:"M6 18L18 6M6 6l12 12"})})})]}),l("div",{className:"p-6 overflow-y-auto space-y-6",children:[a("div",{className:"overflow-x-auto",children:l("table",{className:"w-full text-sm border-collapse text-left",children:[a("thead",{children:l("tr",{className:"bg-gray-50 border-b border-gray-200",children:[a("th",{className:"p-4 font-semibold text-gray-700",children:s("template name")}),a("th",{className:"p-4 font-semibold text-gray-700",children:s("label size (W \xD7 H)")}),a("th",{className:"p-4 font-semibold text-gray-700",children:s("margins (T, R, B, L)")}),a("th",{className:"p-4 font-semibold text-gray-700",children:s("font size")}),a("th",{className:"p-4 font-semibold text-gray-700",children:s("action")})]})}),a("tbody",{className:"divide-y divide-gray-100",children:at.map(e=>{const r=p===e.style;return l("tr",{className:`hover:bg-gray-50/80 transition-colors ${r?"bg-blue-50/30":""}`,children:[l("td",{className:"p-4",children:[l("div",{className:"font-semibold text-gray-900 flex items-center gap-2",children:[s(e.name),r&&a("span",{className:"inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800",children:s("active")})]}),a("div",{className:"text-xs text-gray-500 mt-1 max-w-xs",children:s(e.description)})]}),l("td",{className:"p-4 font-medium text-gray-900",children:[e.width,"mm \xD7 ",e.height,"mm"]}),l("td",{className:"p-4 text-gray-600",children:[s("top"),": ",e.margins.top,"mm, ",s("right"),": ",e.margins.right,"mm, ",a("br",{}),s("bottom"),": ",e.margins.bottom,"mm, ",s("left"),": ",e.margins.left,"mm"]}),l("td",{className:"p-4 font-mono text-gray-700",children:[e.fontSize,"px"]}),a("td",{className:"p-4",children:a("button",{type:"button",onClick:()=>{ba(e.style),ze(!1),y.show(s("applied defaults for ")+s(e.name),"success")},className:"px-3 py-1.5 text-xs font-semibold text-blue-600 hover:text-white hover:bg-blue-600 border border-blue-300 hover:border-blue-600 rounded-md transition-all duration-150",children:s("apply defaults")})})]},e.style)})})]})}),l("div",{className:"bg-amber-50 border border-amber-200 rounded-xl p-4 flex gap-3 text-amber-900 text-sm",children:[a("svg",{className:"w-5 h-5 text-amber-600 shrink-0 mt-0.5",fill:"none",viewBox:"0 0 24 24",stroke:"currentColor",strokeWidth:2,children:a("path",{strokeLinecap:"round",strokeLinejoin:"round",d:"M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"})}),l("div",{children:[a("h4",{className:"font-semibold mb-1",children:s("important integration tips")}),l("ul",{className:"list-disc list-inside space-y-1 text-xs text-amber-800",children:[a("li",{children:s("verify printer driver page sizes are correctly mapped to matches above (e.g. 50x30mm thermal rolls).")}),a("li",{children:s("use lower margins for thermal labels to prevent text cutting and scaling issues.")}),a("li",{children:s("ensure font sizes are kept between 6px and 9px for best scan success on standard barcodes.")})]})]})]})]}),a("div",{className:"bg-gray-50 px-6 py-4 flex justify-end border-t border-gray-100",children:a("button",{type:"button",onClick:()=>ze(!1),className:"px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors",children:s("close")})})]})})]})}export{st as default};
