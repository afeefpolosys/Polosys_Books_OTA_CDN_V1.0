const n=["invoiced"],r=t=>{var e;const s=(e=t==null?void 0:t.status)==null?void 0:e.toString().trim().toLowerCase();return s?!n.includes(s):!0};export{r as c};
