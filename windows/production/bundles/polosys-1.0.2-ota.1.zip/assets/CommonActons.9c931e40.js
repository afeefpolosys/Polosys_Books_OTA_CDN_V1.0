import{A as t}from"./index.667bc0bc.js";function n(o){return{type:t.SET_TOKEN,payload:o}}export{n as s};
