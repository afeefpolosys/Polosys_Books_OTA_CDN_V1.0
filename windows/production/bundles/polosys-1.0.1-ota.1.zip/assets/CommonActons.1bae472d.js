import{A as t}from"./index.5f824bac.js";function n(o){return{type:t.SET_TOKEN,payload:o}}export{n as s};
