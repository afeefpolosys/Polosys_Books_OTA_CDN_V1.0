import{j as o}from"./index.5f824bac.js";const s=()=>o("div",{children:"work flow  logs"});export{s as default};
