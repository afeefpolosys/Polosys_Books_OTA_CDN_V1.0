import{A as t}from"./index.a837e6fc.js";function n(o){return{type:t.SET_TOKEN,payload:o}}export{n as s};
