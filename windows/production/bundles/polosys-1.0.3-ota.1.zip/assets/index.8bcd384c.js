import{j as o}from"./index.a837e6fc.js";const s=()=>o("div",{children:"work flow  logs"});export{s as default};
