module.exports = {
  appId: "com.polosys.books",
  productName: "Polosys Books",
  electronVersion: "44.5.1",
  directories: {
    output: "../release",
  },
  files: [
    "**/*",
  ],
  win: {
    target: [
      {
        target: "nsis",
        arch: ["x64"]
      }
    ],
    icon: "icon.png",
    artifactName: "${productName}-Setup-${version}.${ext}"
  },
  mac: {
    target: [
      {
        target: "dmg",
        arch: ["x64", "arm64"]
      }
    ],
    icon: "icon.png",
    artifactName: "${productName}-${version}-${arch}.${ext}"
  },
  linux: {
    category: "Office",
    maintainer: "Polosys Technologies <info@polosys.com>",
    syncDesktopName: true,
    target: [
      {
        target: "AppImage",
        arch: ["x64"]
      },
      {
        target: "deb",
        arch: ["x64"]
      }
    ],
    icon: "icon.png",
    artifactName: "${productName}-${version}-${arch}.${ext}"
  },
  nsis: {
    oneClick: false,
    allowToChangeInstallationDirectory: true,
    include: "D:\\a\\PolosysBooks_UI_V1.0\\PolosysBooks_UI_V1.0\\electron\\installer.nsh",
  },
  npmRebuild: false,
};
