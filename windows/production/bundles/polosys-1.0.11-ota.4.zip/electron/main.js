const { app, BrowserWindow, shell, ipcMain, safeStorage } = require('electron');
const path = require('path');
const fs = require('fs');
const https = require('https');
const http = require('http');
const { exec } = require('child_process');

const isDev = process.env.NODE_ENV === 'development' || !app.isPackaged;

let mainWindow = null;

// Paths for OTA storage in OS user data directory
const userDataPath = app.getPath('userData');
const otaBundlesDir = path.join(userDataPath, 'ota-bundles');
const otaStateFile = path.join(userDataPath, 'ota-state.json');
const desktopActivationFile = path.join(userDataPath, 'desktop-activation.json');

// Ensure ota-bundles directory exists
if (!fs.existsSync(otaBundlesDir)) {
  try {
    fs.mkdirSync(otaBundlesDir, { recursive: true });
  } catch (err) {
    console.error('[OTA] Failed to create otaBundlesDir:', err);
  }
}

/**
 * Returns the path to the built-in dist directory
 */
function getBuiltInDistDir() {
  const localDist = path.join(__dirname, '../dist');
  if (fs.existsSync(path.join(localDist, 'index.html'))) {
    return localDist;
  }
  return path.join(__dirname, '..');
}

/**
 * Reads local OTA state
 */
function readOtaState() {
  try {
    if (fs.existsSync(otaStateFile)) {
      return JSON.parse(fs.readFileSync(otaStateFile, 'utf8'));
    }
  } catch (err) {
    console.error('[OTA] Failed to read ota-state.json:', err);
  }
  return null;
}

/**
 * Writes local OTA state
 */
function writeOtaState(state) {
  try {
    fs.writeFileSync(otaStateFile, JSON.stringify(state, null, 2), 'utf8');
  } catch (err) {
    console.error('[OTA] Failed to write ota-state.json:', err);
  }
}

/** Reads the activation config from stable per-user Electron storage. */
function readDesktopActivation() {
  try {
    if (!fs.existsSync(desktopActivationFile)) return null;

    const saved = JSON.parse(fs.readFileSync(desktopActivationFile, 'utf8'));
    let config = saved.config;
    if (saved.encrypted && saved.data && safeStorage.isEncryptionAvailable()) {
      config = JSON.parse(safeStorage.decryptString(Buffer.from(saved.data, 'base64')));
    }
    return config && typeof config === 'object' ? config : null;
  } catch (err) {
    console.error('[Desktop] Failed to read activation config:', err);
    return null;
  }
}

/** Saves activation independently of the local server's per-launch port. */
function writeDesktopActivation(config) {
  if (!config || typeof config !== 'object' || Array.isArray(config)) {
    throw new Error('Invalid desktop activation config');
  }

  fs.mkdirSync(userDataPath, { recursive: true });
  const saved = safeStorage.isEncryptionAvailable()
    ? { encrypted: true, data: safeStorage.encryptString(JSON.stringify(config)).toString('base64') }
    : { encrypted: false, config };
  const tempFile = `${desktopActivationFile}.tmp`;
  fs.writeFileSync(tempFile, JSON.stringify(saved), 'utf8');
  fs.renameSync(tempFile, desktopActivationFile);
}

/**
 * Lightweight SemVer comparison supporting -ota.<build> tags
 * Returns true if vA is newer than vB
 */
function isNewerSemver(vA, vB) {
  if (!vA) return false;
  if (!vB) return true;

  const parse = (v) => {
    const [main, ota] = v.split('-ota.');
    const parts = main.split('.').map(n => parseInt(n, 10) || 0);
    const otaBuild = ota ? parseInt(ota, 10) || 0 : 0;
    return { major: parts[0] || 0, minor: parts[1] || 0, patch: parts[2] || 0, otaBuild };
  };

  const a = parse(vA);
  const b = parse(vB);

  if (a.major !== b.major) return a.major > b.major;
  if (a.minor !== b.minor) return a.minor > b.minor;
  if (a.patch !== b.patch) return a.patch > b.patch;
  return a.otaBuild > b.otaBuild;
}

/**
 * Resolves whether to load the active OTA bundle or the built-in dist
 * Includes safety rollback if files are missing or a newer .exe was installed.
 */
function resolveDistPath() {
  const builtInDist = getBuiltInDistDir();
  const builtInIndex = path.join(builtInDist, 'index.html');
  const state = readOtaState();

  if (state && state.activeBundlePath) {
    const otaIndexPath = path.join(state.activeBundlePath, 'index.html');

    if (fs.existsSync(otaIndexPath)) {
      const appVersion = app.getVersion();
      // Fail-safe: If user just installed a newer native .exe package,
      // fallback to the freshly installed built-in dist
      if (state.installedAppVersion && isNewerSemver(appVersion, state.installedAppVersion)) {
        console.log(`[OTA] Newer native app detected (${appVersion} > ${state.installedAppVersion}). Reverting to built-in dist.`);
        writeOtaState({
          ...state,
          activeBundlePath: null,
          activeBundleId: null,
          installedAppVersion: appVersion,
        });
        return builtInIndex;
      }

      console.log(`[OTA] Serving active OTA bundle: ${state.activeBundleId} (${otaIndexPath})`);
      return otaIndexPath;
    } else {
      console.warn(`[OTA] index.html missing at ${otaIndexPath}. Rolling back to built-in dist.`);
      writeOtaState({
        ...state,
        activeBundlePath: null,
        activeBundleId: null,
      });
    }
  }

  console.log(`[OTA] Serving built-in dist: ${builtInIndex}`);
  return builtInIndex;
}

/**
 * Download file helper with redirect handling
 */
function downloadFile(url, destPath) {
  return new Promise((resolve, reject) => {
    const file = fs.createWriteStream(destPath);

    function get(currentUrl, redirectCount = 0) {
      if (redirectCount > 5) {
        file.close(() => fs.unlink(destPath, () => {}));
        return reject(new Error('Too many redirects while downloading bundle'));
      }

      const client = currentUrl.startsWith('https') ? https : http;
      client.get(currentUrl, (response) => {
        if (response.statusCode >= 300 && response.statusCode < 400 && response.headers.location) {
          return get(response.headers.location, redirectCount + 1);
        }

        if (response.statusCode !== 200) {
          file.close(() => fs.unlink(destPath, () => {}));
          return reject(new Error(`Download failed with status: ${response.statusCode}`));
        }

        response.pipe(file);
        file.on('finish', () => {
          file.close(resolve);
        });
      }).on('error', (err) => {
        file.close(() => fs.unlink(destPath, () => {}));
        reject(err);
      });
    }

    get(url);
  });
}

/**
 * Extract ZIP using native Windows PowerShell Expand-Archive (or unzip on Unix)
 */
function extractZip(zipPath, targetDir) {
  return new Promise((resolve, reject) => {
    let command;
    if (process.platform === 'win32') {
      command = `powershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -LiteralPath '${zipPath}' -DestinationPath '${targetDir}' -Force"`;
    } else {
      command = `unzip -o "${zipPath}" -d "${targetDir}"`;
    }

    exec(command, (error, stdout, stderr) => {
      if (error) {
        return reject(new Error(`Extraction error: ${stderr || error.message}`));
      }
      resolve();
    });
  });
}

let localServer = null;
let localServerPort = 0;

const MIME_TYPES = {
  '.html': 'text/html',
  '.js': 'text/javascript',
  '.mjs': 'text/javascript',
  '.css': 'text/css',
  '.json': 'application/json',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.gif': 'image/gif',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon',
  '.woff': 'font/woff',
  '.woff2': 'font/woff2',
  '.ttf': 'font/ttf',
  '.otf': 'font/otf',
  '.pdf': 'application/pdf',
  '.txt': 'text/plain',
  '.webmanifest': 'application/manifest+json',
};

function getActiveDistDir() {
  const builtInDist = getBuiltInDistDir();
  const state = readOtaState();

  if (state && state.activeBundlePath) {
    const otaIndexPath = path.join(state.activeBundlePath, 'index.html');
    if (fs.existsSync(otaIndexPath)) {
      const appVersion = app.getVersion();
      if (state.installedAppVersion && isNewerSemver(appVersion, state.installedAppVersion)) {
        console.log(`[OTA] Newer native app detected (${appVersion} > ${state.installedAppVersion}). Reverting to built-in dist.`);
        writeOtaState({
          ...state,
          activeBundlePath: null,
          activeBundleId: null,
          installedAppVersion: appVersion,
        });
        return builtInDist;
      }
      return state.activeBundlePath;
    } else {
      writeOtaState({
        ...state,
        activeBundlePath: null,
        activeBundleId: null,
      });
    }
  }
  return builtInDist;
}

function startLocalServer() {
  return new Promise((resolve, reject) => {
    if (localServerPort) return resolve(localServerPort);

    localServer = http.createServer((req, res) => {
      try {
        const activeDist = getActiveDistDir();
        let cleanPath = decodeURI((req.url || '/').split('?')[0]);
        if (cleanPath === '/' || cleanPath === '') cleanPath = '/index.html';

        let filePath = path.normalize(path.join(activeDist, cleanPath));

        // Fallback for SPA routing: if file does not exist, serve index.html
        if (!fs.existsSync(filePath) || fs.statSync(filePath).isDirectory()) {
          filePath = path.join(activeDist, 'index.html');
        }

        const ext = path.extname(filePath).toLowerCase();
        const contentType = MIME_TYPES[ext] || 'application/octet-stream';

        fs.readFile(filePath, (err, data) => {
          if (err) {
            res.writeHead(404);
            res.end('Not Found');
          } else {
            res.writeHead(200, {
              'Content-Type': contentType,
              'Access-Control-Allow-Origin': '*',
            });
            res.end(data);
          }
        });
      } catch (err) {
        res.writeHead(500);
        res.end('Internal Server Error');
      }
    });

    localServer.listen(0, '127.0.0.1', () => {
      localServerPort = localServer.address().port;
      console.log(`[LocalServer] Serving Polosys Books at http://127.0.0.1:${localServerPort}`);
      resolve(localServerPort);
    });

    localServer.on('error', (err) => {
      console.error('[LocalServer] Server error:', err);
      reject(err);
    });
  });
}

/**
 * Main application window creation
 */
async function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1366,
    height: 768,
    minWidth: 1024,
    minHeight: 700,
    title: 'Polosys Books',
    icon: path.join(__dirname, '../public/favicon.ico'),
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      nodeIntegration: false,
      contextIsolation: true,
      webSecurity: true,
    },
  });

  if (isDev) {
    mainWindow.loadURL('http://localhost:3002');
    mainWindow.webContents.openDevTools();
  } else {
    try {
      await startLocalServer();
      mainWindow.loadURL(`http://127.0.0.1:${localServerPort}`);
    } catch (err) {
      console.error('[LocalServer] Fallback to loadFile due to error:', err);
      mainWindow.loadFile(resolveDistPath());
    }
  }

  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    shell.openExternal(url);
    return { action: 'deny' };
  });
}

// -------------------------------------------------------------
// IPC Handlers for OTA Updates
// -------------------------------------------------------------

ipcMain.handle('desktop-get-activation', () => readDesktopActivation());

ipcMain.handle('desktop-save-activation', (_event, config) => {
  writeDesktopActivation(config);
  return { success: true };
});

ipcMain.handle('ota-get-current-state', async () => {
  const state = readOtaState();
  const builtInDist = getBuiltInDistDir();
  return {
    isDev,
    activeBundleId: state?.activeBundleId || null,
    builtInVersion: app.getVersion(),
    installedAppVersion: state?.installedAppVersion || app.getVersion(),
    builtInPath: path.join(builtInDist, 'index.html'),
  };
});

ipcMain.handle('ota-download-and-extract', async (event, { bundleUrl, bundleId }) => {
  if (!bundleUrl || !bundleId) {
    return { success: false, error: 'Missing bundleUrl or bundleId' };
  }

  const safeBundleId = bundleId.replace(/[^a-zA-Z0-9._-]/g, '_');
  const tempZipPath = path.join(otaBundlesDir, `temp-${safeBundleId}.zip`);
  const targetDir = path.join(otaBundlesDir, safeBundleId);

  try {
    console.log(`[OTA] Downloading update from: ${bundleUrl}`);
    await downloadFile(bundleUrl, tempZipPath);
    console.log(`[OTA] Downloaded to: ${tempZipPath}`);

    // Create target extraction directory
    if (!fs.existsSync(targetDir)) {
      fs.mkdirSync(targetDir, { recursive: true });
    }

    console.log(`[OTA] Extracting to: ${targetDir}`);
    await extractZip(tempZipPath, targetDir);

    // Normalize directory if zip contained a nested root folder (e.g. dist/)
    let indexHtmlPath = path.join(targetDir, 'index.html');
    if (!fs.existsSync(indexHtmlPath)) {
      const nestedDist = path.join(targetDir, 'dist');
      if (fs.existsSync(path.join(nestedDist, 'index.html'))) {
        const files = fs.readdirSync(nestedDist);
        for (const file of files) {
          const src = path.join(nestedDist, file);
          const dest = path.join(targetDir, file);
          fs.renameSync(src, dest);
        }
        try { fs.rmdirSync(nestedDist); } catch (e) {}
      }
    }

    // Verify index.html exists in targetDir
    if (!fs.existsSync(path.join(targetDir, 'index.html'))) {
      throw new Error('Extracted bundle is missing index.html');
    }

    // Config Preservation: copy local config.json if present
    const builtInConfig = path.join(getBuiltInDistDir(), 'config.json');
    const targetConfig = path.join(targetDir, 'config.json');
    if (fs.existsSync(builtInConfig) && !fs.existsSync(targetConfig)) {
      try {
        fs.copyFileSync(builtInConfig, targetConfig);
      } catch (e) {
        console.warn('[OTA] Could not copy config.json:', e);
      }
    }

    // Update OTA state
    writeOtaState({
      activeBundleId: bundleId,
      activeBundlePath: targetDir,
      installedAppVersion: app.getVersion(),
      lastUpdated: new Date().toISOString(),
    });

    // Cleanup temp zip
    try {
      if (fs.existsSync(tempZipPath)) fs.unlinkSync(tempZipPath);
    } catch (e) {}

    // Cleanup older bundle folders to prevent disk bloat
    try {
      const allDirs = fs.readdirSync(otaBundlesDir);
      for (const dirName of allDirs) {
        if (dirName !== safeBundleId && !dirName.endsWith('.zip')) {
          const oldPath = path.join(otaBundlesDir, dirName);
          fs.rmSync(oldPath, { recursive: true, force: true });
        }
      }
    } catch (e) {
      console.warn('[OTA] Cleanup of old bundles warning:', e);
    }

    console.log(`[OTA] Bundle ${bundleId} successfully extracted and activated.`);
    return { success: true, bundleId };
  } catch (error) {
    console.error('[OTA] Download/extraction failed:', error);
    // Cleanup failed target on error
    try {
      if (fs.existsSync(tempZipPath)) fs.unlinkSync(tempZipPath);
      if (fs.existsSync(targetDir)) fs.rmSync(targetDir, { recursive: true, force: true });
    } catch (e) {}
    return { success: false, error: error.message };
  }
});

ipcMain.handle('ota-reset-to-builtin', async () => {
  const state = readOtaState();
  if (state) {
    writeOtaState({
      ...state,
      activeBundleId: null,
      activeBundlePath: null,
    });
  }
  if (mainWindow) {
    if (isDev) {
      mainWindow.reload();
    } else if (localServerPort) {
      mainWindow.loadURL(`http://127.0.0.1:${localServerPort}`);
    } else {
      mainWindow.loadFile(resolveDistPath());
    }
  }
  return { success: true };
});

ipcMain.handle('reload-app', async () => {
  if (mainWindow) {
    if (isDev) {
      mainWindow.reload();
    } else if (localServerPort) {
      mainWindow.loadURL(`http://127.0.0.1:${localServerPort}`);
    } else {
      mainWindow.loadFile(resolveDistPath());
    }
  }
  return { success: true };
});

// Local printer support retained from the previous desktop entry point.
ipcMain.handle('get-printers', async () => {
  if (!mainWindow) return [];
  try {
    return await mainWindow.webContents.getPrintersAsync();
  } catch (err) {
    console.error('[Printer] Failed to get printers:', err);
    return [];
  }
});

ipcMain.handle('print-pdf', async (_event, options = {}) => {
  if (!options.data) throw new Error('Missing PDF data');

  const printWindow = new BrowserWindow({
    show: false,
    webPreferences: { contextIsolation: true, nodeIntegration: false, sandbox: true },
  });

  try {
    await printWindow.loadURL(`data:application/pdf;base64,${options.data}`);
    return await new Promise((resolve, reject) => {
      printWindow.webContents.print(
        { silent: options.silent !== false, deviceName: options.deviceName, printBackground: true },
        (success, failureReason) => {
          if (!printWindow.isDestroyed()) printWindow.destroy();
          if (success) resolve({ success: true });
          else reject(new Error(failureReason || 'PDF printing failed'));
        }
      );
    });
  } catch (err) {
    if (!printWindow.isDestroyed()) printWindow.destroy();
    throw err;
  }
});

// App Lifecycle
app.whenReady().then(async () => {
  await createWindow();

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit();
  }
});

app.on('will-quit', () => {
  if (localServer) {
    try {
      localServer.close();
    } catch (e) {}
  }
});
