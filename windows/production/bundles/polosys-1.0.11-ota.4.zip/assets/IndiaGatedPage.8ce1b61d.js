import{ca as s,j as t,L as n}from"./index.af913c01.js";const p=({flag:a,children:e})=>s(a)?t(n,{children:e}):null;export{p as I};
