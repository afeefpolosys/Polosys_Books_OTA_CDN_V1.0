import{av as t}from"./index.af913c01.js";function e(o){return{type:t.SET_TOKEN,payload:o}}export{e as s};
