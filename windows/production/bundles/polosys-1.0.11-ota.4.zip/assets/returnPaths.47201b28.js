const t="/accountant/gst_returns",n="/accountant/gstr2b_reconciliation";export{n as G,t as a};
