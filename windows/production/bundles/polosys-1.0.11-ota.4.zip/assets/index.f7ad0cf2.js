import{j as o}from"./index.af913c01.js";const s=()=>o("div",{children:"work flow  logs"});export{s as default};
