import{A as t}from"./index.0a0fb86e.js";function n(o){return{type:t.SET_TOKEN,payload:o}}export{n as s};
