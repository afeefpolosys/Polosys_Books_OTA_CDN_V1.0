import{j as o}from"./index.0a0fb86e.js";const s=()=>o("div",{children:"work flow  logs"});export{s as default};
