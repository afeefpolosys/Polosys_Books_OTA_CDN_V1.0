import{j as o}from"./index.cc0cc30f.js";const s=()=>o("div",{children:"work flow  logs"});export{s as default};
