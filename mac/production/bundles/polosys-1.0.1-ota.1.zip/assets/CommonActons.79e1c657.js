import{A as t}from"./index.cc0cc30f.js";function n(o){return{type:t.SET_TOKEN,payload:o}}export{n as s};
