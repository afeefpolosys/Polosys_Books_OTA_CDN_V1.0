const { app, BrowserWindow, shell, ipcMain } = require('electron');
const path = require('path');
const fs = require('fs');
const https = require('https');
const http = require('http');
const { exec } = require('child_process');

const isDev = process.env.NODE_ENV === 'development' || !app.isPackaged;

let mainWindow = null;

// Paths for OTA storage in OS user data directory
const userDataPath = app.getPath('userData');
const otaBundlesDir = path.join(userDataPath, 'ota-bundles');
const otaStateFile = path.join(userDataPath, 'ota-state.json');

// Ensure ota-bundles directory exists
if (!fs.existsSync(otaBundlesDir)) {
  try {
    fs.mkdirSync(otaBundlesDir, { recursive: true });
  } catch (err) {
    console.error('[OTA] Failed to create otaBundlesDir:', err);
  }
}

/**
 * Returns the path to the built-in dist directory
 */
function getBuiltInDistDir() {
  const localDist = path.join(__dirname, '../dist');
  if (fs.existsSync(path.join(localDist, 'index.html'))) {
    return localDist;
  }
  return path.join(__dirname, '..');
}

/**
 * Reads local OTA state
 */
function readOtaState() {
  try {
    if (fs.existsSync(otaStateFile)) {
      return JSON.parse(fs.readFileSync(otaStateFile, 'utf8'));
    }
  } catch (err) {
    console.error('[OTA] Failed to read ota-state.json:', err);
  }
  return null;
}

/**
 * Writes local OTA state
 */
function writeOtaState(state) {
  try {
    fs.writeFileSync(otaStateFile, JSON.stringify(state, null, 2), 'utf8');
  } catch (err) {
    console.error('[OTA] Failed to write ota-state.json:', err);
  }
}

/**
 * Lightweight SemVer comparison supporting -ota.<build> tags
 * Returns true if vA is newer than vB
 */
function isNewerSemver(vA, vB) {
  if (!vA) return false;
  if (!vB) return true;

  const parse = (v) => {
    const [main, ota] = v.split('-ota.');
    const parts = main.split('.').map(n => parseInt(n, 10) || 0);
    const otaBuild = ota ? parseInt(ota, 10) || 0 : 0;
    return { major: parts[0] || 0, minor: parts[1] || 0, patch: parts[2] || 0, otaBuild };
  };

  const a = parse(vA);
  const b = parse(vB);

  if (a.major !== b.major) return a.major > b.major;
  if (a.minor !== b.minor) return a.minor > b.minor;
  if (a.patch !== b.patch) return a.patch > b.patch;
  return a.otaBuild > b.otaBuild;
}

/**
 * Resolves whether to load the active OTA bundle or the built-in dist
 * Includes safety rollback if files are missing or a newer .exe was installed.
 */
function resolveDistPath() {
  const builtInDist = getBuiltInDistDir();
  const builtInIndex = path.join(builtInDist, 'index.html');
  const state = readOtaState();

  if (state && state.activeBundlePath) {
    const otaIndexPath = path.join(state.activeBundlePath, 'index.html');

    if (fs.existsSync(otaIndexPath)) {
      const appVersion = app.getVersion();
      // Fail-safe: If user just installed a newer native .exe package,
      // fallback to the freshly installed built-in dist
      if (state.installedAppVersion && isNewerSemver(appVersion, state.installedAppVersion)) {
        console.log(`[OTA] Newer native app detected (${appVersion} > ${state.installedAppVersion}). Reverting to built-in dist.`);
        writeOtaState({
          ...state,
          activeBundlePath: null,
          activeBundleId: null,
          installedAppVersion: appVersion,
        });
        return builtInIndex;
      }

      console.log(`[OTA] Serving active OTA bundle: ${state.activeBundleId} (${otaIndexPath})`);
      return otaIndexPath;
    } else {
      console.warn(`[OTA] index.html missing at ${otaIndexPath}. Rolling back to built-in dist.`);
      writeOtaState({
        ...state,
        activeBundlePath: null,
        activeBundleId: null,
      });
    }
  }

  console.log(`[OTA] Serving built-in dist: ${builtInIndex}`);
  return builtInIndex;
}

/**
 * Download file helper with redirect handling
 */
function downloadFile(url, destPath) {
  return new Promise((resolve, reject) => {
    const file = fs.createWriteStream(destPath);

    function get(currentUrl, redirectCount = 0) {
      if (redirectCount > 5) {
        file.close(() => fs.unlink(destPath, () => {}));
        return reject(new Error('Too many redirects while downloading bundle'));
      }

      const client = currentUrl.startsWith('https') ? https : http;
      client.get(currentUrl, (response) => {
        if (response.statusCode >= 300 && response.statusCode < 400 && response.headers.location) {
          return get(response.headers.location, redirectCount + 1);
        }

        if (response.statusCode !== 200) {
          file.close(() => fs.unlink(destPath, () => {}));
          return reject(new Error(`Download failed with status: ${response.statusCode}`));
        }

        response.pipe(file);
        file.on('finish', () => {
          file.close(resolve);
        });
      }).on('error', (err) => {
        file.close(() => fs.unlink(destPath, () => {}));
        reject(err);
      });
    }

    get(url);
  });
}

/**
 * Extract ZIP using native Windows PowerShell Expand-Archive (or unzip on Unix)
 */
function extractZip(zipPath, targetDir) {
  return new Promise((resolve, reject) => {
    let command;
    if (process.platform === 'win32') {
      command = `powershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -LiteralPath '${zipPath}' -DestinationPath '${targetDir}' -Force"`;
    } else {
      command = `unzip -o "${zipPath}" -d "${targetDir}"`;
    }

    exec(command, (error, stdout, stderr) => {
      if (error) {
        return reject(new Error(`Extraction error: ${stderr || error.message}`));
      }
      resolve();
    });
  });
}

/**
 * Main application window creation
 */
function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1366,
    height: 768,
    minWidth: 1024,
    minHeight: 700,
    title: 'Polosys Books',
    icon: path.join(__dirname, '../public/favicon.ico'),
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      nodeIntegration: false,
      contextIsolation: true,
      webSecurity: true,
    },
  });

  if (isDev) {
    mainWindow.loadURL('http://localhost:3002');
    mainWindow.webContents.openDevTools();
  } else {
    mainWindow.loadFile(resolveDistPath());
  }

  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    shell.openExternal(url);
    return { action: 'deny' };
  });
}

// -------------------------------------------------------------
// IPC Handlers for OTA Updates
// -------------------------------------------------------------

ipcMain.handle('ota-get-current-state', async () => {
  const state = readOtaState();
  const builtInDist = getBuiltInDistDir();
  return {
    isDev,
    activeBundleId: state?.activeBundleId || null,
    builtInVersion: app.getVersion(),
    installedAppVersion: state?.installedAppVersion || app.getVersion(),
    builtInPath: path.join(builtInDist, 'index.html'),
  };
});

ipcMain.handle('ota-download-and-extract', async (event, { bundleUrl, bundleId }) => {
  if (!bundleUrl || !bundleId) {
    return { success: false, error: 'Missing bundleUrl or bundleId' };
  }

  const safeBundleId = bundleId.replace(/[^a-zA-Z0-9._-]/g, '_');
  const tempZipPath = path.join(otaBundlesDir, `temp-${safeBundleId}.zip`);
  const targetDir = path.join(otaBundlesDir, safeBundleId);

  try {
    console.log(`[OTA] Downloading update from: ${bundleUrl}`);
    await downloadFile(bundleUrl, tempZipPath);
    console.log(`[OTA] Downloaded to: ${tempZipPath}`);

    // Create target extraction directory
    if (!fs.existsSync(targetDir)) {
      fs.mkdirSync(targetDir, { recursive: true });
    }

    console.log(`[OTA] Extracting to: ${targetDir}`);
    await extractZip(tempZipPath, targetDir);

    // Normalize directory if zip contained a nested root folder (e.g. dist/)
    let indexHtmlPath = path.join(targetDir, 'index.html');
    if (!fs.existsSync(indexHtmlPath)) {
      const nestedDist = path.join(targetDir, 'dist');
      if (fs.existsSync(path.join(nestedDist, 'index.html'))) {
        const files = fs.readdirSync(nestedDist);
        for (const file of files) {
          const src = path.join(nestedDist, file);
          const dest = path.join(targetDir, file);
          fs.renameSync(src, dest);
        }
        try { fs.rmdirSync(nestedDist); } catch (e) {}
      }
    }

    // Verify index.html exists in targetDir
    if (!fs.existsSync(path.join(targetDir, 'index.html'))) {
      throw new Error('Extracted bundle is missing index.html');
    }

    // Config Preservation: copy local config.json if present
    const builtInConfig = path.join(getBuiltInDistDir(), 'config.json');
    const targetConfig = path.join(targetDir, 'config.json');
    if (fs.existsSync(builtInConfig) && !fs.existsSync(targetConfig)) {
      try {
        fs.copyFileSync(builtInConfig, targetConfig);
      } catch (e) {
        console.warn('[OTA] Could not copy config.json:', e);
      }
    }

    // Update OTA state
    writeOtaState({
      activeBundleId: bundleId,
      activeBundlePath: targetDir,
      installedAppVersion: app.getVersion(),
      lastUpdated: new Date().toISOString(),
    });

    // Cleanup temp zip
    try {
      if (fs.existsSync(tempZipPath)) fs.unlinkSync(tempZipPath);
    } catch (e) {}

    // Cleanup older bundle folders to prevent disk bloat
    try {
      const allDirs = fs.readdirSync(otaBundlesDir);
      for (const dirName of allDirs) {
        if (dirName !== safeBundleId && !dirName.endsWith('.zip')) {
          const oldPath = path.join(otaBundlesDir, dirName);
          fs.rmSync(oldPath, { recursive: true, force: true });
        }
      }
    } catch (e) {
      console.warn('[OTA] Cleanup of old bundles warning:', e);
    }

    console.log(`[OTA] Bundle ${bundleId} successfully extracted and activated.`);
    return { success: true, bundleId };
  } catch (error) {
    console.error('[OTA] Download/extraction failed:', error);
    // Cleanup failed target on error
    try {
      if (fs.existsSync(tempZipPath)) fs.unlinkSync(tempZipPath);
      if (fs.existsSync(targetDir)) fs.rmSync(targetDir, { recursive: true, force: true });
    } catch (e) {}
    return { success: false, error: error.message };
  }
});

ipcMain.handle('ota-reset-to-builtin', async () => {
  const state = readOtaState();
  if (state) {
    writeOtaState({
      ...state,
      activeBundleId: null,
      activeBundlePath: null,
    });
  }
  if (mainWindow) {
    mainWindow.loadFile(resolveDistPath());
  }
  return { success: true };
});

ipcMain.handle('reload-app', async () => {
  if (mainWindow) {
    if (isDev) {
      mainWindow.reload();
    } else {
      mainWindow.loadFile(resolveDistPath());
    }
  }
  return { success: true };
});

// App Lifecycle
app.whenReady().then(() => {
  createWindow();

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit();
  }
});
