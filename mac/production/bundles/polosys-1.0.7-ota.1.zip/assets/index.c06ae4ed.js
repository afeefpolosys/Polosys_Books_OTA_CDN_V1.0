import{j as o}from"./index.1ba3b4f7.js";const s=()=>o("div",{children:"work flow  logs"});export{s as default};
