import{A as t}from"./index.1ba3b4f7.js";function n(o){return{type:t.SET_TOKEN,payload:o}}export{n as s};
