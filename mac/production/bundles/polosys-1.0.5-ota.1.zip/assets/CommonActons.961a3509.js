import{A as t}from"./index.f4bfac30.js";function n(o){return{type:t.SET_TOKEN,payload:o}}export{n as s};
