import{j as o}from"./index.f4bfac30.js";const s=()=>o("div",{children:"work flow  logs"});export{s as default};
