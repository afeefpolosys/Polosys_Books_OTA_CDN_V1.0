import{j as o}from"./index.519d3dbe.js";const s=()=>o("div",{children:"work flow  logs"});export{s as default};
