import{c9 as s,j as t,L as n}from"./index.519d3dbe.js";const p=({flag:e,children:a})=>s(e)?t(n,{children:a}):null;export{p as I};
