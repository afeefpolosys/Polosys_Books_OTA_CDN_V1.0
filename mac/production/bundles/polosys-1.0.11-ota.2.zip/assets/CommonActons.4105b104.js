import{av as t}from"./index.519d3dbe.js";function e(o){return{type:t.SET_TOKEN,payload:o}}export{e as s};
